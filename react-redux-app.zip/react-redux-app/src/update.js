import React,{Component} from 'react'
import { bindActionCreators } from 'C:/Users/learning/AppData/Local/Microsoft/TypeScript/3.4.3/node_modules/redux';
import { connect } from 'react-redux';

class Update extends Component
{
    render()
    {
        return (
            <div>
            <table>
            <tr>
            <th><label>ID:</label></th>
            <td><input type = "text"  readonly ref = "id" defaultValue = {this.props.location.state.product.id}/></td>
            </tr>
            <tr>
            <th><label>Name:</label></th>
            <td><input type = "text"   ref = "name" defaultValue = {this.props.location.state.product.name}/></td>
            </tr>
            <tr>
            <th><label>Cost:</label></th>
            <td><input type = "number"   ref = "cost" defaultValue = {this.props.location.state.product.cost}/></td>
            </tr>
            <tr>
            <th><label>Description:</label></th>
            <td><input type = "text"   ref = "des" defaultValue = {this.props.location.state.product.description}/></td>
            </tr>
            <tr><button onClick={()=>{
                this.props.dispatch({type:'update',i:this.props.location.state.product.id,n:this.refs.name.value,c:this.refs.cost.value,d:this.refs.des.value})
                this.props.history.push("/")
            }}>Save</button></tr>
            </table>
            
            </div>
        );
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
        actions:bindActionCreators(dispatch)
    }
}
export default connect(mapDispatchToProps) (Update);