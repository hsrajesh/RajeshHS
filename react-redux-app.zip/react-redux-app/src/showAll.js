import React,{Component} from 'react'
import {connect} from 'react-redux'
import {Link} from 'react-router-dom'
import { type } from 'os';
import { bindActionCreators } from 'C:/Users/learning/AppData/Local/Microsoft/TypeScript/3.4.3/node_modules/redux';

class Show extends Component
{
    render()
    {
        return (
            <div align = "center">
                <table border = "2">
                <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Cost</th>
                <th>Description</th>
                </tr>
                {this.props.productsstate.products.map((p,i)=>(
                    <tr key = {i}>
                    <td>{p.id}</td>
                    <td>{p.name}</td>
                    <td>{p.cost}</td>
                    <td>{p.description}</td>
                    <td><Link to = {{pathname :"/update", state: {product:p}}}>Update</Link></td>
                    <td><button onClick = {()=>{
                        this.props.dispatch({type: "delete",i:p.id})
                        // window.location.reload("/")
                        this.props.history.push("/")
                    }}>Delete</button></td>
                    </tr>
                ))}
                </table>
                <Link to = "/add">Add products</Link>
            </div>
        );
    }
}
const mapStateToProps = (state)=>{
    return {
        productsstate:state.productsreducer
    }
}

export default connect(mapStateToProps)(Show)