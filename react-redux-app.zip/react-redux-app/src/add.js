import React,{Component} from 'react'
import { connect } from 'react-redux';
import { bindActionCreators } from 'C:/Users/learning/AppData/Local/Microsoft/TypeScript/3.4.3/node_modules/redux';


class Add extends Component
{
    render()
    {
        return (
            <div>
            <table>
            <tr>
            <th><label>ID:</label></th>
            <td><input type = "text" ref = "id"/></td>
            </tr>
            <tr>
            <th><label>Name:</label></th>
            <td><input type = "text" ref = "name"/></td>
            </tr>
            <tr>
            <th><label>Cost:</label></th>
            <td><input type = "number" ref = "cost"/></td>
            </tr>
            <tr>
            <th><label>Description:</label></th>
            <td><input type = "text" ref = "des"/></td>
            </tr>
            <tr><button onClick={()=>{
                this.props.dispatch({type:'add',i:this.refs.id.value,n:this.refs.name.value,c:this.refs.cost.value,d:this.refs.des.value})
                this.props.history.push("/")
            }}>Add</button></tr>
            </table>
            </div>
        )
    }
}
const mapDispatchToProps= (dispatch)=>{
    return {
        actions:bindActionCreators(dispatch)
    }
}
export default connect(mapDispatchToProps)(Add);