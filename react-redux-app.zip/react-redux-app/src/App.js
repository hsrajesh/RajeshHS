import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Route} from 'react-router-dom'
import Show from './showAll';
import Update from './update';
import Add from './add';

function App() {
  return (
    <div>
     <BrowserRouter>
     <Route exact path = "/" component = {Show}/>
     <Route path = "/update" component = {Update}/>
     <Route path = "/add" component = {Add}/>
     </BrowserRouter>
    </div>
  );
}

export default App;
