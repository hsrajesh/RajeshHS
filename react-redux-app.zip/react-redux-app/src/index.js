import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { combineReducers, createStore } from 'redux';
import {Provider} from 'react-redux'

//application state
//step1 :declare and intialize state of an application
let initialstate = {
    products:[
        {id:1,name:"Pen",cost:20,description:"Stationary"},
        {id:2,name:"Pencil",cost:10,description:"Stationary"},
        {id:3,name:"Laptop",cost:50000,description:"Electronics"},
        {id:4,name:"Mobile",cost:20000,description:"Electronics"}
    ]
}

//step: Creating a reducer -- creating a new state
let productsreducer = (state = initialstate,action)=>{
    switch(action.type)
    {
        case 'add':
        let p = state.products;
        var body = {id:action.i,name:action.n,cost:action.c,description:action.d}
        p.push(body)
        state = {
            products:p
        }
        return state;
        case 'update':
        let pr = state.products;
        pr.map((p,i)=>{
            if(p.id == action.i){
            p.name = action.n;
            p.cost = action.c;
            p.description = action.d;
            }
        })
        state = {
            products:pr
        }
        return state;
        case 'delete':
        let p1 = state.products;
        p1.map((b,i)=>{
            if(b.id == action.i)
            {
                p1.splice(i,1)
            }
        })
        state = {
            products :p1
        }
        return state;
        default:
        return state;
    }
}
let reducer = combineReducers({productsreducer})

//step 3: create redux store

const store = createStore(reducer)

//step 4: pass redux store to react


ReactDOM.render(<Provider store = {store}><App /></Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
