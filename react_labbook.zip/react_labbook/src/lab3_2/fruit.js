import React,{Component} from 'react'
import FruitType from './fruitType';

class Fruit extends Component
{
    render()
    {
        return (
            <div>
            <FruitType />
            </div>
            )
    }
}
export default Fruit