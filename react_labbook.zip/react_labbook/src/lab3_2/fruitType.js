import React,{Component} from 'react'
import ReactList from '../lab3_3';

class FruitType extends Component
{
    state = {
        fruits:[
          'Apples',
          'Blueberries',
          'Strawberries',
          'Bananas'
  
        ]
              
      }
    render()
    {
        return (
            <div>
            <h4>Lab 3.2</h4>
           {this.state.fruits.map((p,i)=>(
               <ul>  
               <li>{p}</li>
               </ul>
           ))}
           <hr></hr>
           <ReactList fruits = {this.state.fruits}/>
            </div>
            )
    }
}
export default FruitType