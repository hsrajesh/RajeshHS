import React,{Component} from 'react'
import Axios from 'axios';

class Search extends Component
{
    
    searchEmployee = ()=>{
        let n = this.refs.eid.value;
        Axios.get("http://localhost:4000/search/" +n )
        .then((res)=>{
           this.props.history.push({pathname : "/ssdata" ,state:{employee:res.data}})
        })
    }
    render()
    {
        return (
            <div>
            <p></p>
            Enter Employee Id to be Searched:
            <input type = "number" ref = "eid"/><br></br>
            <button onClick = {this.searchEmployee}>Search</button>
            </div>
        )
    }
}
export default Search;