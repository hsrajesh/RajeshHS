import React,{Component} from 'react'
import {Link} from 'react-router-dom'
import Axios from 'axios';

class Add extends Component
{
    addEmployee = ()=>{
        let i = this.refs.id.value;
        let n = this.refs.name.value;
        let s = this.refs.sal.value;
        let d = this.refs.dept.value;
        var body = {id:i,name:n,salary:s,dept:d}
        Axios.post("http://localhost:4000/add",body)
        .then(()=>{
        this.props.history.push("/show")
    });
}
    render()
    {
        return (
            <div align = "center">
            <p></p>
            <h3>Add Employee</h3>
            <table>
            <tr>
            <th><label>ID:</label></th>
            <td><input type = "number" ref = "id"/></td>
            </tr>
            <tr>
            <th><label>Name:</label></th>
            <td><input type = "text" ref = "name"/></td>
            </tr>
            <tr>
            <th><label>Salary:</label></th>
            <td><input type = "number" ref = "sal"/></td>
            </tr>
            <tr>
            <th><label>Deaprtment:</label></th>
            <td><input type = "text" ref = "dept"/></td>
            </tr>
            </table>
            <button class = "btn btn-success" onClick = {this.addEmployee}>Add Employee</button>
            </div>
        )
    }
}
export default Add;