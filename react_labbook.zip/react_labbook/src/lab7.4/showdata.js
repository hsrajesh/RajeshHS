import React,{Component} from 'react'
import Axios from 'axios';

class ShowData extends Component
{
   
    render()
    {
        if(this.props.location.state.employee != ''){
        return (
            <div>
            <p></p>
            <table border = "2" class = "table table-striped">
            <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Employee Salary</th>
            <th>Employee Department</th>
            </tr>
            <tr>
            <td>{this.props.location.state.employee.id}</td>
            <td>{this.props.location.state.employee.name}</td>
            <td>{this.props.location.state.employee.salary}</td>
            <td>{this.props.location.state.employee.department}</td>
            </tr>
            </table>
            </div>
        )
        }
        else
        {
            return (
                <div>Employee Data Not Found</div>
            )
        }
    }
}
export default ShowData;