import React,{Component} from 'react'
import {Link} from 'react-router-dom'
import Axios from 'axios'

class Show extends Component
{
    state = {
        employee:[]
    }
    constructor()
    {
        super()
        Axios.get("http://localhost:4000/show").then((res)=>{
            this.setState({employee:res.data})
        })
    }
    deleteEmployee = (i)=>{
        Axios.delete("http://localhost:4000/delete/" + i).then(()=>{
            window.location.reload("/show")
        })
    }
    render()
    {
        return (
            <div align = "center">
            <p></p>
            <table border = "2" class = "table table-striped">
            <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Employee Salary</th>
            <th>Employee Department</th>
            <th>Action</th>
            </tr>
            {this.state.employee.map((e,i)=>(
                <tr key = {i}>
                <td>{e.id}</td>
                <td>{e.name}</td>
                <td>{e.salary}</td>
                <td>{e.department}</td>
                <td><button onClick ={()=>this.deleteEmployee(e.name)} >Delete</button></td>
                </tr>
            ))}
            </table>
            </div>
        )
    }
}
export default Show;