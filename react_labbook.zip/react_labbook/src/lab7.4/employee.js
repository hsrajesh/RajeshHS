var mongo = require("mongodb")
var url = "mongodb://localhost:27017/fullstack"
var express = require("express")
var cors = require("cors")
var bp = require("body-parser")

var app = express();
app.use(cors())
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.listen(4000,()=>{console.log("server connected")})

app.get("/show",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("Employee").find().toArray((err,result)=>{
            return res.send(result)
        })
    })
})

app.post("/add",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        var b = {id:parseInt(req.body.id),name:req.body.name,salary:parseInt(req.body.salary),department:req.body.dept}
        db.db("fullstack").collection("Employee").insertOne(b,(err,result)=>{
            return res.send("added")
        })
    })
})

app.get("/search/:rid",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        var d = req.params.rid;
        db.db("fullstack").collection("Employee").findOne({id:parseInt(d)},(err,result)=>{
            return res.send(result)
        })
    })
})

app.delete("/delete/:id",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("Employee").deleteOne({name:req.params.id},(err,result)=>{
            return res.send("deleted")
        })
    })
})
