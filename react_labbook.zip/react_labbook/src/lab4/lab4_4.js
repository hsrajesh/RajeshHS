import React,{Component} from 'react'
import {Input ,Form,FormGroup,Row,Col ,Button} from 'reactstrap'

class Register extends Component
{
    render()
    {
        let st1 = {width:'100%'}
        let st2 = {color:'green'}
        return (
            <div align = "center">
            <h3>Lab 4.4</h3>
            <h4 align = "center">--------------Register----------------</h4>
            <p align = "center">Create your account.It's free and only takes a minute</p>
            <Form>
            <Row>
                <Col>
                    <FormGroup>
                        <Input type = "text" name = "first" placeholder = "FirstName"/>
                    </FormGroup>
                </Col>
                <Col>
                <FormGroup>
                <Input type = "text" name = "last" placeholder = "LastName"/>
                </FormGroup>
                </Col>
            </Row>
            <Row>
                <Col>
                    <FormGroup>
                    <Input type = "email" name = "email"  placeholder = "Email"/>
                    </FormGroup>
            </Col>
            </Row>
            <Row>
                <Col>
                    <FormGroup>
                        <Input type = "password" name = "pass"  placeholder = "PassWord"/>
                    </FormGroup>
                </Col>
            </Row>
            <Row>
                 <Col>
                    <FormGroup>
                        <Input type = "password" name = "confirm"  placeholder = "Confirm Password"/>
                    </FormGroup>
                </Col>
            </Row>
            <Row>
            <Col>
            <FormGroup>
            <Input type  = "checkbox" />I accept the <a href = "#">Terms of Use</a> & <a href = "#">Privacy Policy</a>
            </FormGroup>
            </Col>
            </Row>
            <Row>
            <Col>
            <FormGroup>
            <Button color = "success" style = {st1}>Register Now</Button>
            </FormGroup>
            </Col>
            </Row>
            </Form>
            Already have an account? <a href = "#">Sign In</a>
            <hr></hr>
            </div>
        )
    }
}
export default Register;