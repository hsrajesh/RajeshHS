import React,{Component} from 'react'

class Login extends Component
{
    render()
    {
        let st1 = {"background-color":'green',width:'100%'}
        let st2 = {color:'darkgreen'}
        return (
            <div align = "center">
            <h4>Lab 4.1</h4>
            <table border = "2">
            <tr><td style = {st2} colspan = "2">Log-in to your account</td></tr>
            <tr>
            <th><label>UserName:</label></th>
            <td><input type = "text" placeholder = "Username"/></td>
            </tr>
            <tr>
            <th><label>Password:</label></th>
            <td><input type = "password" placeholder = "Password"/></td>
            </tr>
            <tr>
            <th colspan = "2"><button  style = {st1}>Login</button></th>
            </tr>
            </table>
            <hr></hr>
            </div>
        )
    }
}
export default Login;