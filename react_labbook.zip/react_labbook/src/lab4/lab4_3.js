import React,{Component} from 'react'

class RegisterB extends Component
{
    render()
    {
        let st2 = {width:'100%'}
        return (
            <div align = "center">
            <h3>Lab 4.3</h3>
            <h4 align = "center">Register</h4>
            <p align = "center">Create your account.It's free and only takes a minute</p>
            <table border = "2" class = "table table-striped">
            <tr>
            <td><input type = "text" placeholder = "UserName"/></td>
            <td><input type = "text" placeholder = "Password"/></td>
            </tr>
            <tr>
            <th colspan = "2"><input type = "email"placeholder = "Email" style = {st2}/></th>
            </tr>
            <tr>
            <th colspan = "2"><input type = "password"placeholder = "Password" style = {st2}/></th>
            </tr>
            <tr>
            <th colspan = "2"><input type = "password"placeholder = "Confirm Password" style = {st2}/></th>
            </tr>
            <tr>
                <td colspan = "2"><input type = "checkbox"/>I accept the <a href = "#">Terms of Use </a> & <a href = "#">Privacy Policy</a> </td>
            </tr>
            <tr>
            <td colspan = "2"><button style = {st2} class = "btn btn-success">Register Now</button></td>
            </tr>
            </table>
            Already have an account? <a href = "#">Sign In</a>
            <hr></hr>
            </div>
        )
    }
}
export default RegisterB;