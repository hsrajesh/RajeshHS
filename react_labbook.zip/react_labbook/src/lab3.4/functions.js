import React,{Component} from 'react'


function FunComp()
{
    return (
        <div align = "center">
        <h4>Function Component</h4>
        <input type ="text" placeholder = "Text here"/><br></br>
        <input type ="text" placeholder = "Text here"/>
        <hr></hr>
        </div>
    )
}
export default FunComp;