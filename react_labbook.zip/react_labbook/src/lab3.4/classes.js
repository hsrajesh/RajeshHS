import React,{Component} from 'react'


class Classes extends Component
{
    state =
    {
        mname:this.props.mname,
        mprice:this.props.mprice
    }
    chnageInfo = ()=>{
        this.setState({mname:'Avengers',mprice:180})
        }
        render()
        {
            return (
                <div align = "center">  
                <h4>Lab 3.4</h4>   
                <h4>Class Component</h4>  
                Movie Name: {this.state.mname}<br></br>
                Movie price:{this.state.mprice} <br></br>
                <button onClick = {this.chnageInfo}>Click to Chnage</button><br></br>
               -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                </div>
            )
        }
}
export default Classes;