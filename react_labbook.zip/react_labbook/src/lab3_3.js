import React,{Component} from 'react'

class ReactList extends Component
{
    render()
    {
        return (
            <div>
            <h4>Lab3.3</h4>
            <ol>
            {this.props.fruits.map((p,i)=>(
                
                <li key = {i}>{p}</li>
            ))}
            </ol>
            <hr></hr>
            </div>
        )
    }
}
export default ReactList;