import React,{Component} from 'react'

class MovieList extends Component
{
    state =
    {
        mname:this.props.mname,
        mprice:this.props.mprice
    }
    chnageInfo = ()=>{
        this.setState({mname:'Avengers',mprice:180})
    }
    render()
    {
        return (
            <div align = "center">
            <h4>Lab 3.1</h4>
            Movie Name: {this.state.mname}<br></br>
            Movie price:{this.state.mprice} <br></br>
            <button onClick = {this.chnageInfo}>Click to Chnage</button>
            <hr></hr>
            </div>
        )
    }
}
export default MovieList;