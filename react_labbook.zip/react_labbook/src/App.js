import React from 'react';
import logo from './logo.svg';
import './App.css';
import HelloWorld from './lab1';
import MovieList from './lab3_1';
import Fruit from './lab3_2/fruit';
import FruitType from './lab3_2/fruitType';
import Classes from './lab3.4/classes';
import Functions from './lab3.4/functions';
import Login from './lab4/lab4_1';
import Register from './lab4/lab4_4';
import RegisterB from './lab4/lab4_3';
import JSX from './lab2';
import SignIn from './lab9/signin';
import FunComp from './lab3.4/functions';
import Home from './lab7.4/show';
import Add from './lab7.4/add';
import {BrowserRouter,Link,Route} from 'react-router-dom'
import Show from './lab7.4/show';
import Search from './lab7.4/search';
import ShowData from './lab7.4/showdata';

function App() {
  return (
    <div className = "App">
      {/*<HelloWorld />
      <JSX />
      <MovieList  mname = "Maharshi" mprice= "350"/>
      <Fruit />
      <Classes mname = "Maharshi" mprice= "350"/>
      <FunComp />
      <Login />
      <Register />
      <RegisterB />
      <SignIn />*/}
      <BrowserRouter>
      <Link to = "/addE" class = "btn btn-primary">Add</Link>&nbsp;
      <Link to = "/Show" class = "btn btn-secondary">Show</Link>&nbsp;
      <Link to = "/search" class = "btn btn-info">Search</Link>&nbsp;
      <Link to = "/ssdata" class = "btn btn-success">Show Searched Data</Link>&nbsp;
      <Route  path = "/addE" component = {Add}/>
      <Route path = "/show" component = {Show}/>
      <Route path = "/search" component = {Search}/>
      <Route path = "/ssdata" component = {ShowData}/>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
