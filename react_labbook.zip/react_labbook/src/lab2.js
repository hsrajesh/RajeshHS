import React,{Component} from 'react'

class JSX extends Component
{
    render()
    {
        return (
            <div align = "center">
            <h4>Lab2</h4>
            <input type = "text"/><br></br>
            <input type = "text"/>
            <hr></hr>
            </div>
        )
    }
}
export default JSX;