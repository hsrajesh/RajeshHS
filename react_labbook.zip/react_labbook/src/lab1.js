import React,{Component} from 'react'

class HelloWorld extends Component
{
    render()
    {
        return (
            <div align = "center">
            <h4>Lab1</h4>
            <h1>Hello World</h1>
            <hr></hr>
            </div>
        )
    }
}
export default HelloWorld;