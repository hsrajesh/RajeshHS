import React,{Component} from 'react'


class SignIn extends Component
{
    state = {
        username:'',
        password:''
    }
    LogIn = ()=>{
        this.setState({username:this.refs.name.value,password:this.refs.pass.value})
    }
    signOut = ()=>{

        this.setState({username : '',password : ''})
    }
    render()
    {
        if(this.state.username == '' && this.state.password ==''){
        return (
            <div align = "center">
            <h1>Login Page</h1>
            <input type = "text" ref = "name" placeholder = "Enter Username"/><br></br>
            <input type = "password" ref = "pass" placeholder = "Enter Password"/><br></br>
            <button onClick = {this.LogIn}>SignIn</button>
            </div>    
        )
        }
        else
        {
            return (
                <div align = "center">
                <h1>Login Page</h1>
                Welcome {this.state.username}
                <a href = "#" onClick = {this.signOut}>Sign out</a>
                </div>
            )
        }
    }
}
export default SignIn