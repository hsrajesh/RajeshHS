import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { GamesService } from '../games.service';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  game_details;
  amount = 600;
  constructor(private http:HttpClient,private cd:GamesService) { 


    this.http.get("http://localhost:3000/game/")
    .subscribe((data)=>{

      this.game_details = data;
    })

    this.cd.getAmount(this.amount)
  }

  ngOnInit() {
  }

}
