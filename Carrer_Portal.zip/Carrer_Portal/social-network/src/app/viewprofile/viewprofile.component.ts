import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.css']
})
export class ViewprofileComponent implements OnInit {
  d = new Date()
  user_data;fname;fnames;
  user_details;
  user_fname;
  count=0;fullname;
  user_lname;clgyear;p;id;
  user_clgyear;status;user_course;user_cllg;user_skills;user_degree;ucompnay;udesg;ucity;ucloaction
  constructor(private http:HttpClient,private activate:ActivatedRoute,private cd:SocialService) {

    this.activate.params.subscribe((parameters)=>{
      this.id = parameters['id']
    })
    this.user_data =this.cd.userData(this.id).subscribe((data)=>{
      this.user_data = data;
      this.checkData()
    })
   }
   checkData()
   {
     this.user_fname = this.user_data.user_firstname;
     this.user_lname = this.user_data.user_lastname;
     this.user_degree = this.user_data.user_degree;
     this.user_course = this.user_data.user_stream;
     this.user_cllg = this.user_data.user_college
     this.user_clgyear =this.user_data.user_clgto;
     this.user_skills = this.user_data.user_skills;
     this.ucity = this.user_data.user_city;
     this.ucloaction = this.user_data.user_location;
     this.ucompnay = this.user_data.user_cmpname;
     this.fullname = this.user_fname + this.user_lname;
      this.clgyear = this.user_clgyear.slice(0,4)
      if(this.clgyear < this.d.getFullYear)
        {
            this.status = "Studied"
        }
        else
        {
          this.status  = "Studying"
        }
   }
   countLike()
   {
     this.count = this.count + 1;
     var body = {id:this.id,count:this.count}
     var head = new HttpHeaders({'Content-Type':'application/json'})
     this.http.put("http://localhost:5000/addcount",body,{headers:head}).subscribe(()=>{
       alert("added")
     })

   }
  ngOnInit() {
  }

}
