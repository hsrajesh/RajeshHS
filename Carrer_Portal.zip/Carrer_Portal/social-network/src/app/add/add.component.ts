import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  fname;lname;skill;hdeg;collg;from;to;cname;exp;clocation;city;desig;pecent;stream;
  id;user_data;email;mob;
  constructor(private http:HttpClient,private route:Router,private activate:ActivatedRoute,private cd:SocialService) 
  { 
    this.activate.params.subscribe((parameters)=>{
      this.id = parameters['id']
    })
    this.user_data = this.cd.userData(this.id).subscribe((data)=>{
      this.user_data = data;
      this.email= this.user_data.user_email;
      this.mob = this.user_data.user_mobile;
    })
  }

  ngOnInit() {
  }

  add()
  {
    if(!(this.fname =='' && this.lname == '' && this.skill == '' && this.hdeg == '' && this.collg == '' && this.from == '' && this.to == '' && this.cname == '' && this.exp == '' && this.clocation == '' && this.city == '' && this.desig == '' && this.pecent == '' && this.stream == '')){
    var emp = {fname:this.fname,lname:this.lname,skill:this.skill,college:this.collg,from:this.from,to:this.to,cmpname:this.cname,cexp:parseInt(this.exp),location:this.clocation,city:this.city,designation:this.desig,stream:this.stream,percentage:this.pecent,highdegree:this.hdeg}
    var head = new HttpHeaders({'Content-Type':'application/json'})
    this.http.put("http://localhost:5000/addprof/"+this.id,emp,{headers:head})
    .subscribe(()=>{
      this.route.navigate(['profile'])
      alert("addedd")
    })

  }
}
}
