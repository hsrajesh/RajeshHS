import { Component, OnInit } from '@angular/core';
import { Router, Data, ActivatedRoute } from '@angular/router';
import { SocialService } from '../social.service';
import { HttpClient } from '@angular/common/http';
import { FriendsComponent } from '../friends/friends.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
   d = new Date()
   id;
  fname;fnames;
  user_details;
  user_data;
  user_fname;
  user_lname;clgyear;p;
  user_clgyear;status;user_course;user_cllg;user_skills;user_degree;ucompnay;udesg;ucity;ucloaction

  constructor(private router:Router,private cd:SocialService,private http:HttpClient,private activate:ActivatedRoute) {
    this.user_details = this.cd.getData()
    .subscribe((data)=>{
      this.user_details = data;
      this.p = this.user_details;
    })

    this.http.get("http://localhost:5000/getprof")
    .subscribe((data)=>{
      this.user_data = data;
      // this.checkData()
    })
    this.activate.params.subscribe((parameters)=>{
        this.id = parameters['id']
    })
  }
  searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
   countLike()
   {
      
   }
  ngOnInit() {
  }

}
