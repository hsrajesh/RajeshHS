import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(fnames,text): any {
    let fa = [];
    if (!fnames) {
      return [];
    }
    if (!text) {
      return fnames;
    }
    text = text.toLowerCase();
    return fnames.filter(it => {
      return it.toLowerCase().includes(text);
    });
  }
  

}
