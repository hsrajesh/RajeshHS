import { Component, OnInit, Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SocialService } from '../social.service';
import { request } from 'http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user_details;
  fname;
  fnames;
  request="Connection";
  uid;
  constructor(private router:Router,private http:HttpClient,private cd:SocialService,private activate:ActivatedRoute) {
   
    this.uid = this.activate.snapshot.paramMap.get('id')
    this.user_details = this.cd.getData()
    .subscribe((data)=>{
        this.user_details = data;
    })
   }
   searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })

    }
   }
   sendRequest()
   {
      this.request ='Connection Sent'
   }
  ngOnInit() {
  }

}
