import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SocialService {
  constructor(private http:HttpClient) {
  }
  getDetails(p)
  {
    return this.http.get("http://localhost:5000/getFriend/" + p)
  }

  getData()
  {
    return this.http.get("http://localhost:5000/get")
  }

  userData(n)
  {
    return this.http.get("http://localhost:5000/getprof/"+ n)
  }
}
