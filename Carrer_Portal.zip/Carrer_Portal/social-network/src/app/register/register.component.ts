import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, Validators, EmailValidator } from '@angular/forms';
import { SocialService } from '../social.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  mail='';
  pass='';
  cpass='';
  namef='';
  namel='';
  num='';
  fullname;
  user_id;
  id;
  message='';
  user_details;
  constructor(private http:HttpClient,private router:Router,private cd:SocialService) {

    this.user_details = this.cd.getData()
    .subscribe((data)=>{
        this.user_details = data;
    })
    // this.user_id = parseInt(Math.random()*10)
  }

  fname = new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]{1,}')])
  lname = new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]{1,}')])
  email = new FormControl('',[Validators.required,Validators.email])
  password = new FormControl('',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[#$@_]).{8,15}')])
  cpassword = new FormControl('',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[#$@_]).{8,15}')])
  contact = new FormControl('',[Validators.required,Validators.pattern('[6-9][0-9]{9}')])

  getFnameErrors()
  {
      return this.fname.hasError('required')?'First Name is Required':this.fname.hasError('pattern')?'Only Charcters':'';
  }
  getLnameErrors()
  {
      return this.lname.hasError('required')?'Last Name is Required':this.lname.hasError('pattern')?'Only Charcters':'';
  }
  getPasswordErrors()
  {
      return this.password.hasError('required')?'Password is Required':this.password.hasError('pattern')?'Password Should contain alphanumeric and spacial Characters':'';
  }
  getEmailErrors()
  {
      return this.email.hasError('required')?'First Name is Required':this.email.hasError('email')?'Email Invalid':'';
  }
  getContactErrors()
  {
    return this.contact.hasError("required")?'Contact No is Required':this.contact.hasError("pattern")?'Invalid':''
  }
  getConfirmPass()
  {
    if(this.cpass != this.pass)
    {
      return this.cpassword.hasError('required')?'Confirm Password is Required':this.cpassword.hasError('pattern')?'Password doesnot match':'';
    }
  }
  register()
  {
    this.fullname = this.namef +" " +  this.namel;
    if(this.fullname != '' && this.mail != '' && this.num.length != 0 && this.pass.length != 0)
    {
      this.id = (Math.random()*10);
      this.user_id = parseInt(this.id)
      var json  ={id:this.user_id,name:this.fullname,email:this.mail,num:this.num,pass:this.pass}
      var head = new HttpHeaders({'Content-Type':'application/json'})
      this.http.post("http://localhost:5000/add",json,{headers:head})
      .subscribe(()=>{
      })
      this.message = "Registered Successfully"
    }
  }

  ngOnInit() {
  }

}
