import React,{Component} from 'react'
import Axios from 'axios';

class CourseJson extends Component
{
    state = {
        course:[]
    }
    constructor()
    {
        super()
        Axios.get("http://localhost:3000/course")
        .then((res)=>this.setState({course:res.data}))
    }
    render()
    {
        return (
            <div>
            {this.state.course.map((m,i)=>(
                <ul>
                <li>{m.name}&nbsp; &nbsp;{m.Price}</li>
                </ul>
            ))}
            </div>
        )
    }
}
export default CourseJson;