import React,{Component} from 'react'
import {Link} from 'react-router-dom'

class Home extends Component
{
    render()
    {
        let st = {color:'blue'}
        return (
            <div>
            <h1 style = {st}>Hello Play Course Application</h1>
            <Link to = "/course">Course</Link><br></br>
            <Link to = "/coursejson">Course With JSON</Link>
            </div>
        )
    }
}
export default Home;