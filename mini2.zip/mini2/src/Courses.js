import React,{Component} from 'react'
import {Link} from 'react-router-dom'

class Course extends Component
{
    state = 
    {
        course:
        [
            {name:"Course 1", duration:150},
            {name:"Course 2", duration:100},
            {name:"Course 3", duration:50}
        ]
    }
    addCourse = ()=>{
        let n = this.refs.name.value;
        let d = this.refs.cdur.value;
        var body = {name:n,duration:d}
        let ts = this.state.course;
        ts.push(body)
        this.setState({course:ts})
        this.refs.name.value = ""
        this.refs.cdur.value = ""
    }
    getDuration = ()=>{
        let n = this.refs.cname.value
        this.state.course.map((c,i)=>{
            if(c.name == n)
            {
                alert("Duration is " + c.duration)
            }
        })
        this.refs.cname.value = ""
    }
    render()
    {
        return (
            <div>
            {this.state.course.map((c,i)=>(
                <ul>
                <li><Link>{c.name}</Link></li>
                </ul>
            ))}
            <hr></hr>
            <p><b>Add Course</b></p>
            <label>Course Name:</label>
            <input type = "text" ref = "name"/><br></br>
            <label>Course Duration:</label>
            <input type = "number" ref = "cdur"/><br></br>
            <button onClick = {this.addCourse}>Add Course</button><br>
            </br><hr></hr>
            <label>Enter Course Name:</label>
            <input type = "text" ref = "cname"/>
            <button onClick = {this.getDuration}>Get Duration</button>
            </div>
        )
    }
}
export default Course;