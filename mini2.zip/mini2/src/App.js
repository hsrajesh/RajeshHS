import React from 'react';
import logo from './logo.svg';
import './App.css';
import Course from './Courses';
import {BrowserRouter , Link ,Route} from 'react-router-dom'
import Home from './Home';
import CourseJson from './coursejson';

function App() {
  return (
    <div >
     <BrowserRouter>
     <div>
     <Route exact path = "/" component = {Home}/>
     <Route  path = "/course" component = {Course}/>
     <Route  path = "/coursejson" component = {CourseJson}/>
     </div>
     </BrowserRouter>
    </div>
  );
}

export default App;
