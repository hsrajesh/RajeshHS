var mongo = require("mongodb").MongoClient

var url = "mongodb://localhost:27017/fullstack"

mongo.connect(url,(err,database)=>{

    if(err)throw err;
    console.log("Connected....")
    //create a collection
    var d  =  database.db("fullstack").createCollection("customers", (err,res)=>{
        if(err)throw err;
        console.log("collection created successfully.....")
    })
   
    //     let cus = [
    //         // {_id:3,name:"latha",city:"Banaglore",mobile:9591423721},
    //         {_id:4,name:"katha",city:"Mumbai",mobile:959135968},
    //         {_id:5,name:"matha",city:"Pune",mobile:95359523485}
    //     ]
    //    database.db("fullstack").collection("customers").insert(cus,(err,msg)=>{

    //     if(err) throw err;
    //     console.log(msg)

    //    })

        //retrieve the data from database

        // database.db("fullstack").collection("customers").find().toArray((err,result)=>{

        //     if(err)throw err;
        //     console.log(result)
        // })

        //retrieve the data of id is 2

        // database.db("fullstack").collection("customers").find().toArray(_id =2,(err,result)=>{

        //     if(err) throw err;
        //     console.log(result)
        // })
        // database.db("fullstack").collection("customers").find({_id:2}).toArray((err,sum)=>{

        //     if(err) throw err;
        //     console.log(sum)
        // })
        database.db("fullstack").collection("customers").update({name:"latha"},{$set:{city:"Chennai"}},(err,result)=>{
            console.log(result)
        })
        database.db("fullstack").collection("customers").find().toArray((err,result)=>{

                if(err)throw err;
                console.log(result)
        })
        database.db("fullstack").collection("customers").remove({name:"latha"},(err,msg)=>{
            console.log("deleted.....")
        })
        // database.db("fullstack").collection("customers").find().sort({_id:1}).toArray((err,res)=>{
        //     console.log(res)
        // })
        database.db("fullstack").collection("customers").find().sort({name:1}).limit(2).toArray((arr,res)=>{
            console.log(res)
        })
    database.db("fullstack").collection("customers").find({name:/h.*/}).toArray((err,res)=>{
        console.log(res)
    })
    database.db("fullstack").collection("customers").find({city:{$in: ["Mumbai","Pune"]}}).toArray((err,res)=>{

        console.log(res)
    })
})