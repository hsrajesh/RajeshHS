var http = require("http")
var url = require("url")

var server  = http.createServer((req,res)=>{

    res.writeHead(200,{'Content-Type':'text/html'})
    var q = url.parse(req.url,true)
    var d = q.query;
    res.write("Username is " + d.name + "<br>")
    res.write("Password is " + d.password)
    res.end()


})
// server.listen(8000,()=> {console.log("server listening at http://localhost:8000")})
server.listen(8000,()=> {console.log("server listening at http://localhost:8000")})