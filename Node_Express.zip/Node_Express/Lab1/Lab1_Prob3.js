var file = require("fs")

var data = "This is my First Project";

file.appendFile("sample.txt",data,(err,res)=>{

    if(err) throw err;
    console.log("Written the data successfully")
})