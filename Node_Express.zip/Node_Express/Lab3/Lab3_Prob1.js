
var mdb = require("mongodb");
var url = "mongodb://localhost:27017/fullstack"
var express = require("express")
var bp = require("body-parser")



var app = express();

app.use(bp.urlencoded({extended:true}))
app.use(bp.json())


mdb.connect(url,(err,db)=>{

    db.db("fullstack").createCollection("employee", (err,res)=>{

        if(err) throw err;
        console.log("created successfully")
    })
})

app.post("/employees",(req,res)=>{

    mdb.connect(url,(err,database)=>{
            if(err) throw err;
           
            var data = {empID:parseInt(req.body.empID),empName:req.body.empName,empSalary:parseInt(req.body.empSalary),city:req.body.city,state:req.body.state}
        database.db("fullstack").collection("employee").insertOne(data,(err,res2)=>{
            res.send(res2);
            res.end();
        })
    })
})

app.listen(9000,()=>{console.log("server connected... at http://localhost:9000")})

app.get("/employees",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("employee").find().toArray((err,resut)=>{

            res.send(resut);
            res.end();
        })
    })
})

// app.delete("/employees",(req,res)=>{

//     mdb.connect(url,(err,db)=>{

//         db.db("fullstack").collection("employee").remove((err,result)=>{

//                 res.send("deleted");
//                 res.end();
//         })
        
//     })
// })