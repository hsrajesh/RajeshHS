console.log("This is my first node app");
console.log("hello world!")
console.log("hello, goodevening")
console.log("Welcome to Capgemini")