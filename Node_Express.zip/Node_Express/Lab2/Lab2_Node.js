var mongo = require("mongodb").MongoClient

var url = "mongodb://localhost:27017/fullstack"

mongo.connect(url,(err,db)=>{

    if(err) throw err;
    console.log("connected...")

    db.db("fullstack").createCollection("product",(err,msg)=>{

        if(err) throw err;
        console.log(" Product collection created")
    })

    //creating two arrays
    var products = 
    [
            {_id:1,p_name:"soap",p_cost:20,p_description:"grocery"},
            {_id:2,p_name:"MotoG3",p_cost:15000,p_description:"Electronics"}
    ]

    //inserting an array to collection
    db.db("fullstack").collection("product").insert(products,(err,res)=>{

        if(err) throw err;
        console.log(res)
    })

    // fetching the data from an collection
    db.db("fullstack").collection("product").find({_id:2}).toArray((err,result)=>{
            console.log(result)
    })
    
    //deleting the data based on ID
    db.db("fullstack").collection("product").remove({_id:7},(err,res)=>{

        console.log("deleted...")
    })

    //updating the data based on ID   
    db.db("fullstack").collection("product").update({_id:2},{$set:{p_cost:20000}},(err,res)=>{

        console.log("updated")
    })

    //adding one more array to an collection
    var d = {_id:8,p_name:"Book",p_cost:50,p_decsription:"Stationary"}
    db.db("fullstack").collection("product").insert(d,(e,res)=>{

        if(e) throw e;
        console.log("inserted")
    })

    //fetching the data from an collection
    db.db("fullstack").collection("product").find().toArray((err,res)=>{

        console.log(res)
    })

    //Sorting the array in ascending order
    db.db("fullstack").collection("product").find().sort({_id:1}).toArray((err,res)=>{

        console.log(res)
    })
})