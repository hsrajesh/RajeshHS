var express = require("express")
var bp = require("body-parser")

var app = express()
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())

app.listen(9000,()=>{console.log("server listening at http://localhost:9000")})


app.get('/hello',(req,res)=>{

    res.send("Processing get request....")
    res.end()
})

app.post("/hello",(req,res)=>{

res.send("processing to post request...");
res.end();
})

app.put("/hello/:id",(req,res)=>{

    res.send("processing put request for given id " + req.params.id );
    res.end();
})

app.delete("/hello/:id",(req,res)=>{

    res.send("Processing delete request for given id is " + req.params.id);
    res.end()
})

app.get('/haii/:id',(req,res)=>{

    res.send("Processing get request...." + req.params.id)
    res.end()
})

app.post("/haii",(req,res)=>{

    // res.send("processing to post request...");

    res.send("Name : " + req.body.name + "<br>"  + "City : " + req.body.city  + "<br>" + "Mobile NO : " + req.body.Mobile);
    res.end();
})