var mdb = require("mongodb")
var express = require("express")
var bp = require("body-parser")
var url = "mongodb://localhost:27017/fullstack"
var app = express();

app.use(bp.urlencoded({extended:JSON}))
app.use(bp.json())
app.listen(2000,()=>{console.log("server connected....at http://localhost:2000")})


app.get("/products",(req,res)=>{

    mdb.connect(url,(err,db)=>{
        if(err) throw err;

        var d = req.query
        db.db("fullstack").collection("customers").find().toArray((err,data)=>{

            if(err) throw err;
            res.send(data);
            res.end();
        })
    })
})

// app.get("/products/:pname",(req,res)=>{


//     mdb.connect(url,(err,db)=>{

//         db.db("fullstack").collection("customers").find({"name":req.params.pname}).toArray((err,data)=>{

//             res.send(data);
//             res.end();
//         })
//     })
// })

// app.get("/products/:id",(req,res)=>{

//     mdb.connect(url,(err,dbo)=>{
//         var d = req.params.id
//         dbo.db("fullstack").collection("customers").find({city:d}).toArray((err,data)=>{
//             res.send(data);
//             res.end();
//         })
//     })
// })

// app.post("/products",(req,res)=>{

//     mdb.connect(url,(err,msg)=>{

//         var a = {name:req.body.name,city:req.body.city,mobile:req.body.Mobile}
//         msg.db("fullstack").collection("customers").insertOne(a,(err,result)=>{

//             if(err) throw err;
//             res.send(result)
//             res.end();
//         })
//     })
// })

// app.put("/products/:name",(req,res)=>{

//     mdb.connect(url,(err,db)=>{
//             var rr = req.params.name;
//         db.db("fullstack").collection("customers").update({"_id":5},{$set:{"name":rr}},(err,result)=>{

//                 if(err) throw err;
//                 res.send(result);
//                 res.end();
//         })
//     })
// })

app.delete("/products/:name",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("customers").remove({"name":req.params.name},(err,result)=>{

            res.send(result)
            res.end();
        })
    })
})