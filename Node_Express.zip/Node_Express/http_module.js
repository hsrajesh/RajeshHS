var http = require("http")
var file = require("fs")
var url  = require("url")

var data = "Welcome to Hyderabad"
file.writeFile("simple.txt",data)

var server = http.createServer((req,res)=>{
//    file.readFile("simple.txt",(err,data)=>{
//     res.writeHead(200,{'Content-Type':'text/html'})
//     res.write(data.toString());
//     res.end();
// })
    var q = url.parse(req.url,true);
    res.writeHead(200, {'Content-Type':'text/html'})
    var d = q.query
    res.write("username is : " + d.name + "<br>");
    res.write("password: " + q.query.pass);
    res.end();

})
server.listen(8000,()=> {console.log("server listening at http://localhost:8000")})