var file = require("fs")

var data = "This is a demo for file module";

// file.writeFile("test.txt",data,(err,msg)=>{

//     if(err) throw err;
//     console.log("The data written successfully")
// })

file.appendFile("sample.txt",data,(err,res)=>{

    if(err) throw err;
    console.log("Sucesss")
})
file.readFile("sample.txt",(err,res)=>{
    if(err) throw err;
    console.log("data written successfully")
    console.log(res.toString())
})
