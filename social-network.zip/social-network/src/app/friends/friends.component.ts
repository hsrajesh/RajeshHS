import { Component, OnInit } from '@angular/core';
import { SocialService } from '../social.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {

  count=0;
  friends;fnamee;fnames;user_details;
  constructor(private dc:SocialService,private http:HttpClient) {

    this.friends = this.dc.getData().subscribe((data)=>{
        this.friends = data;
    })

    this.user_details = this.dc.getData().subscribe((data)=>{
      this.user_details = data;
    })

   }
   searchFriends()
   {
     if(this.fnamee == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fnamee) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
  ngOnInit() {
  }

}
