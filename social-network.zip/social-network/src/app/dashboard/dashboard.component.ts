import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  count=0;
  user_details;
  user_profile;
  eid= 1;fnames;fnamee;

  ename;
  fname;lname;skill;hdeg;collg;from;to;cname;exp;clocation;city;desig;pecent;stream;

  constructor(private http:HttpClient,private router:Router,private cd:SocialService)
  {
    this.http.get("http://localhost:5000/getprof")
    .subscribe((data)=>{
      this.user_details = data;
      this.showDetails()
    })

  }
  searchFriends()
   {
     if(this.fnamee == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fnamee) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
  showDetails()
  {
    this.user_details.forEach((p)=>{
      this.fname = p.user_firstname;
      this.lname = p.user_lastname;
      this.skill = p.user_skills;
      this.hdeg = p.user_degree;
      this.collg = p.user_college;
      this.from = p.user_clgfrom;
      this.to = p.user_clgto;
      this.stream = p.user_stream;
      this.pecent = p.user_percentage;
      this.city = p.user_city;
      this.cname = p.user_cmpname;
      this.exp = p.user_cmpexp;
      this.clocation = p.user_location;
      this.desig = p.user_designation;
    });
  }
  Save()
  {
    var emp = {id:this.eid,fname:this.fname,lname:this.lname,skill:this.skill,college:this.collg,from:this.from,to:this.to,cmpname:this.cname,cexp:parseInt(this.exp),location:this.clocation,city:this.city,designation:this.desig,stream:this.stream,percentage:this.pecent,highdegree:this.hdeg}
    var head = new HttpHeaders({'Content-Type':'application/json'})
    this.http.put("http://localhost:5000/getproffind",emp,{headers:head})
    .subscribe(()=>{
      alert("updated");
    })
  }
  ngOnInit() {
  }

}
