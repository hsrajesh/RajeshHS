import { Component, OnInit } from '@angular/core';
import { Router, Data } from '@angular/router';
import { SocialService } from '../social.service';
import { HttpClient } from '@angular/common/http';
import { FriendsComponent } from '../friends/friends.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
   d = new Date()
  fname;fnames;
  user_details;
  user_data;
  user_fname;
  user_lname;clgyear;p;
  user_clgyear;status;user_course;user_cllg;user_skills;user_degree;ucompnay;udesg;ucity;ucloaction

  constructor(private router:Router,private cd:SocialService,private http:HttpClient) {
    this.user_details = this.cd.getData()
    .subscribe((data)=>{
      this.user_details = data;
      this.p = this.user_details;
    })

    this.http.get("http://localhost:5000/getprof")
    .subscribe((data)=>{
      this.user_data = data;
      this.checkData()
    })
  }
  searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
   checkData()
   {
      this.user_data.map((p,i)=>{
        this.user_fname = p.user_firstname;
        this.user_lname = p.user_lastname;
        this.user_clgyear = p.user_clgto;
        this.user_cllg =p.user_college;
        this.user_course = p.user_stream;
        this.user_skills = p.user_skills;
        this.user_degree = p.user_degree;
        this.ucity = p.user_city;
        this.ucloaction = p.user_location;
        this.ucompnay = p.user_cmpname;
      })
      this.clgyear = this.user_clgyear.slice(0,4)
      if(this.clgyear < this.d.getFullYear)
        {
            this.status = "Studied"
        }
        else
        {
          this.status  = "Studying"
        }
   }
  ngOnInit() {
  }

}
