import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SocialService } from '../social.service';
import { request } from 'http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  user_details;
  fname;
  fnames;
  request="Connection"
  constructor(private router:Router,private http:HttpClient,private cd:SocialService) {
   this.user_details = this.cd.getData()
    .subscribe((data)=>{
        this.user_details = data;
    })
   }
   searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1 || c.user_name == this.fname )
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })

    }
   }
   sendRequest()
   {
      this.request ='Connection Sent'
   }
  ngOnInit() {
  }

}
