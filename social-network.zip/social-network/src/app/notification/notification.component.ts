import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  user_details;
  fname;
  fnames;
  count=0;
  constructor(private http:HttpClient) {
    this.http.get("http://localhost:5000/get")
    .subscribe((data)=>{
        this.user_details = data;
    })
   }

  searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1 || c.user_name == this.fname )
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
  ngOnInit() {
  }

}
