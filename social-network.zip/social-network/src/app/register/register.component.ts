import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  uname;upass;umail;unum;cname;cnum;cmail;cpass;
  constructor(private http:HttpClient,private router:Router) { }

  ngOnInit() {
  }

  userRegister()
  {
      var json ={name:this.uname,mail:this.umail,num:this.unum,pass:this.upass}
      var head = new HttpHeaders({'Content-Type':'application/json'})
      this.http.post("http://localhost:4000/add",json,({headers:head}))
      .subscribe(()=>{
          this.router.navigate([''])
      })

  }
  orgRegister()
  {
      var json ={name:this.cname,mail:this.cmail,pass:this.cpass,num:this.cnum}
      var head = new HttpHeaders({'Content-Type':'application/json'})
      this.http.post("http://localhost:4000/addOrg",json,({headers:head}))
      .subscribe(()=>{
          this.router.navigate([''])
      })
  }
}
