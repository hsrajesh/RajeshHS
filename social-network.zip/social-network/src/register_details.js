var mongo = require("mongodb")
var express = require("express")
var bp = require("body-parser")
var cors = require("cors")
var url = "mongodb://localhost:27017/fullstack"

var app = express()
app.use(cors())
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())

app.listen(4000,()=>{console.log("server connected")})


app.post("/add",(req,res)=>{
  mongo.connect(url,(err,db)=>{
    if(err) throw err;
    var b = {name:req.body.name,email:req.body.mail,mobile:req.body.num,password:req.body.pass}
    db.db("fullstack").collection("userDetails").insertOne(b,(err,result)=>{
      if(err) throw err;
      res.send(result)
    })
  })
})

app.get("/getuser/:mail",(req,res)=>{
  mongo.connect(url,(err,db)=>{
    db.db("fullstack").collection("userDetails").findOne({email:req.params.mail},(err,result)=>{
      res.send(result)
    })
  })
})

app.post("/addOrg",(req,res)=>{
  mongo.connect(url,(err,db)=>{
    if(err) throw err;
    var b = {org_companyname:req.body.name,org_email:req.body.mail,org_mobile:req.body.num,org_pass:req.body.pass}
    db.db("fullstack").collection("org_register").insertOne(b,(err,result)=>{
      if(err) throw err;
      res.send(result)
    })
  })
})


app.get("/getorg/:mail",(req,res)=>{
  mongo.connect(url,(err,db)=>{
    db.db("fullstack").collection("org_register").findOne({org_email:req.params.mail},(err,result)=>{
      res.send(result)
    })
  })
})
