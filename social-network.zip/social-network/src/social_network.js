var mongo = require("mongodb")
var express = require("express")
var cors = require("cors")
var url = "mongodb://localhost:27017/fullstack"
var bp = require("body-parser")

var app = express();
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.use(cors())

app.listen(5000,()=>{console.log("server connected")})

id = 0;
app.post("/add",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        if(err) throw err;
        var b = {user_id:req.body.id,user_name:req.body.name,user_email:req.body.email,user_mobile:req.body.num,user_password:req.body.pass}
        db.db("fullstack").collection("user_register").insertOne(b,(err,result)=>{
            if(err) throw err;
            res.send("added")
        })
    });
})

app.get("/get",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        if(err) throw err;
        db.db("fullstack").collection("user_register").find().toArray((err,result)=>{
            res.send(result)
        })
    })
})
app.post("/addprof",(req,res)=>{
  id = id + 1;
  mongo.connect(url,(err,db)=>{
    if(err) throw err;
    var body = {user_id:id,user_firstname:req.body.fname,user_lastname:req.body.lname,user_skills:req.body.skill,user_degree:req.body.highdegree,user_college:req.body.college,user_clgfrom:req.body.from,user_clgto:req.body.to,user_stream:req.body.stream,
    user_percentage:req.body.percentage,user_city:req.body.city,user_cmpname:req.body.cmpname,user_cmpexp:parseInt(req.body.cexp),user_location:req.body.location,user_designation:req.body.designation}
    db.db("fullstack").collection("user_profile").insertOne(body,(err,result)=>{
      if(err) throw err;
      res.send(result)
    })
  })
})

app.get("/getprof",(req,res)=>{
  mongo.connect(url,(err,db)=>{
      if(err) throw err;
      db.db("fullstack").collection("user_profile").find().toArray((err,result)=>{
        if(err) throw err;
          res.send(result)
      })
  })
})

app.put("/getproffind",(req,res)=>{
  mongo.connect(url,(err,db)=>{
      if(err) throw err;
      db.db("fullstack").collection("user_profile").updateOne({user_id:req.body.id},{$set:{user_firstname:req.body.fname,user_lastname:req.body.lname,user_skills:req.body.skill,user_degree:req.body.highdegree,user_college:req.body.college,user_clgfrom:req.body.from,user_clgto:req.body.to,user_stream:req.body.stream,
        user_percentage:req.body.percentage,user_city:req.body.city,user_cmpname:req.body.cmpname,user_cmpexp:parseInt(req.body.cexp),user_location:req.body.location,user_designation:req.body.designation}},(err,result)=>{
        res.send(result)
      })

  })
})

