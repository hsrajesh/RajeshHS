var mongo = require("mongodb")
var express = require("express")
var cors = require("cors")
var url = "mongodb://localhost:27017/fullstack"
var bp = require("body-parser")

var app = express();
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.use(cors())

app.listen(4000,()=>{console.log("server connected")})


app.post("/add",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        if(err) throw err;
        var b = {user_name:req.body.name,user_email:req.body.email,user_mobile:req.body.num,user_password:req.body.pass}
        db.db("fullstack").collection("user_register").insertOne(b,(err,result)=>{
            if(err) throw err;
            res.send("added")
        })
    });
})

app.get("/get",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        if(err) throw err;
        db.db("fullstack").collection("user_register").find().toArray((err,result)=>{
            res.send(result)
        })
    })
})