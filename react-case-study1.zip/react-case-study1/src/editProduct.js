import React,{Component} from 'react'
import {Form,FormGroup,Label,Col,Input,Button, FormFeedback} from 'reactstrap'
import Axios from 'axios';

class Edit extends Component
{
    state = {
        pid:this.props.location.state.products.id,
        pname:this.props.location.state.products.name,
        pcost:this.props.location.state.products.price,
        pdes:this.props.location.state.products.description
        // pid:'',pname:'',pdes:'',pcost:''
    }
    handleName=(event)=>{
        let m=event.target.value;
        this.setState({pname:m})
    }
    handleDescription=(event)=>{
        let o=event.target.value;
        this.setState({pdes:o})
    }
    handlePrice=(event)=>{
         let p=event.target.value;
         this.setState({pcost:p})
    }
    editProduct=()=>{
        let id = this.props.location.state.products.id;
        var body={name:this.state.pname,description:this.state.pdes,price:this.state.pcost}
        Axios.put("http://localhost:3000/products/" + id,body)
        .then(()=>{this.props.history.push("/")
        })
    }
    render()
    {
        let n = this.state.pname.charAt(0).toUpperCase;
        return (
            <div>
                <Form>
                    <FormGroup row>
                        <Label sm={1}>ID:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleID} defaultValue={this.props.location.state.products.id} readOnly valid={this.props.location.state.products.id.length == 4} />
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Name:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleName} defaultValue={this.props.location.state.products.name} valid={this.state.pname != ''}  invalid={this.state.pname == ''}/>
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Description:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleDescription} defaultValue={this.props.location.state.products.description} valid={this.state.pdes != ''}  invalid={this.state.pdes == ''}/>
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Price:</Label>
                        <Col sm={3}>
                            <Input type="number" onChange={this.handlePrice} defaultValue={this.props.location.state.products.price} valid={this.state.pcost > 0 && this.state.pcost <= 100000} invalid={!(this.state.pcost > 0 && this.state.pcost <= 100000)}/>                         
                        </Col>
                    </FormGroup>
                    <Button disabled={(this.state.pname == '' || !(this.state.pcost > 0 && this.state.pcost <= 100000) || this.state.pdes == '')?true:false} onClick={this.editProduct}>Submit</Button>
                </Form>
            </div>
        )
    }
}
export default Edit;
