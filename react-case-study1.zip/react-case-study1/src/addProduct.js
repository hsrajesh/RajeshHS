import React,{Component} from 'react'
import {Form,FormGroup,Label,Col,Input,Button, FormFeedback} from 'reactstrap'
import Axios from 'axios';


class Add extends Component
{
    state = {
        pid:'',
        pname:'',pcost:'',pdes:''
    }
    handleID =(event)=>{
        let n=event.target.value;
        this.setState({pid:n})
    }
    handleName=(event)=>{
        let m=event.target.value;
        this.setState({pname:m})
    }
    handleDescription=(event)=>{
        let o=event.target.value;
        this.setState({pdes:o})
    }
    handlePrice=(event)=>{
         let p=event.target.value;
         this.setState({pcost:p})
    }
    addProduct=()=>{
        var body={id:this.state.pid,name:this.state.pname,description:this.state.pdes,price:this.state.pcost}
        Axios.post("http://localhost:3000/products",body)
        .then(()=>{this.props.history.push("/")
        })
    }
    render()
    {
        let n = this.state.pname.charAt(0).toUpperCase;
        return (
            <div>
                <Form>
                    <FormGroup row>
                        <Label sm={1}>ID:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleID} valid={this.state.pid.length == 4} invalid={this.state.pid.length != 4}/>
                            <FormFeedback invalid>{this.state.pid.length != 4 ?'ID should be max 4 digits ':''}</FormFeedback>
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Name:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleName} valid={this.state.pname != '' } invalid={this.state.pname == ''}/>
                            <FormFeedback invalid>{this.state.pname == '' ?'Name is Required ':''}</FormFeedback>
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Description:</Label>
                        <Col sm={3}>
                            <Input type="text" onChange={this.handleDescription} valid={this.state.pdes != '' } invalid={this.state.pdes == ''}/>
                            <FormFeedback invalid>{this.state.pdes == '' ?'Description is Required ':''}</FormFeedback>
                        </Col>
                    </FormGroup>
                    <FormGroup row>
                        <Label sm={1}>Price:</Label>
                        <Col sm={3}>
                            <Input type="number" onChange={this.handlePrice} valid={this.state.pcost > 0 && this.state.pcost <= 100000} invalid={!(this.state.pcost > 0 && this.state.pcost <= 100000)}/>
                            <FormFeedback invalid>{!(this.state.pcost > 0 && this.state.pcost <= 100000)?'Price should be between 1 to 100000':''}</FormFeedback>
                        </Col>
                    </FormGroup>
                    <Button disabled={(this.state.pname == '' || !(this.state.pcost > 0 && this.state.pcost <= 100000) || this.state.pdes == '' || this.state.pid.length != 4)?true:false} onClick={this.addProduct}>Submit</Button>
                </Form>
            </div>
        )
    }
}
export default Add;