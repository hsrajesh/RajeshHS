import React,{Component} from 'react'
import Axios from 'axios'
import {Link} from 'react-router-dom'

class Show extends Component
{
    state = {
        products:[]
    }
    constructor()
    {
        super()
        Axios.get("http://localhost:3000/products")
        .then((res)=>{this.setState({products:res.data})})
    }
    deleteProduct=(i)=>{
        Axios.delete("http://localhost:3000/products/" + i)
        .then(()=>{
            window.location.reload()
        })
    }
    render()
    {
        let st1 = {'margin-left':'3%'}
        return (
            <div align="center">
                <table class="table table-striped" border="2">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th colspan = "2">Actions</th>
                    </tr>
                    {this.state.products.map((p,i)=>(
                        <tr>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.description}</td>
                            <td>{p.price}</td>
                            <td><Link to={{pathname:'/edit', state:{products:p}}} class="btn btn-info">Edit</Link>
                            <button class="btn btn-danger" style={st1} onClick={()=>this.deleteProduct(p.id)}>Delete</button></td>
                        </tr>
                    ))}
                </table>
                <Link to="/add" class="btn btn-success">Add Product</Link>
            </div>
        )
    }
}
export default Show;