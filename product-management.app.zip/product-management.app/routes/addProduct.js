var mongo  = require("mongodb")
var express = require("express");
var router = express.Router();
var url = "mongodb://localhost:27017/fullstack";

router.post("/",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        var d = {_id:req.body.id,p_name:req.body.name,p_cost:req.body.cost,p_description:req.body.des}
        db.db("fullstack").collection("product").insertOne(d,(err,result)=>{
            res.redirect("/")
        })
    })
})
module.exports = router;