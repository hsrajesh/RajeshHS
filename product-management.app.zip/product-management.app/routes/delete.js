var mongo = require("mongodb")
var url = "mongodb://localhost:27017/fullstack"
var express = require("express")
var router = express.Router();

router.get("/:name",(req,res)=>{

    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("product").removeOne({p_name:req.params.name},(err,result)=>{
            res.redirect("/")
        })
    })
})
module.exports  = router;