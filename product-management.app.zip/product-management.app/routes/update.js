var express = require("express")
var mongo = require("mongodb")
var url = "mongodb://localhost:27017/fullstack"
var router = express.Router();


router.get("/:name",(req,res)=>{

    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("product").findOne({p_name:req.params.name},(err,result)=>{

            res.render("update",{products:result})
        })
    })

})

module.exports = router;