var mongo = require("mongodb");
var express = require("express");
var router = express.Router();
var url = "mongodb://localhost:27017/fullstack";

router.get("/",(req,res)=>{
    res.render("add")
})

module.exports = router;