var express = require('express');
var router = express.Router();
var mdb = require("mongodb");
var url = "mongodb://localhost:27017/fullstack"

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  mdb.connect(url,(err,db)=>{
    db.db("fullstack").collection("product").find().sort({_id:1}).toArray((err,result)=>{
      res.render("index",{products:result})
    })
  })
});

module.exports = router;
