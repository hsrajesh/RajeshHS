var express = require("express")
var router = express.Router();
var mongo = require("mongodb")
var url = "mongodb://localhost:27017/fullstack"

router.post("/",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("product").updateOne({p_name:req.body.name},{$set:{p_name:req.body.name,p_cost:req.body.cost}},(err,rseult)=>{
            res.redirect('/')
        })
    })
})

module.exports = router;
