import React,{Component} from 'react'
import Axios from 'axios';
import {BrowserRouter ,Link} from 'react-router-dom'

class Show extends Component
{
    state = {
        product:[]
    }

    constructor()
    {
        super()
        Axios.get("http://localhost:4000/all")
        .then((res)=>this.setState({product:res.data}))
    
    }
    deleteP = (i) =>{
      
        Axios.delete("http://localhost:4000/delete/" + i)
        .then(()=>{
            window.location.reload("/")
        })
    }
    render()
    {
        return (
            <div align = "center">
            <table border = "2" class = "table table-striped">
            <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Cost</th>
            <th>Description</th>
            <th colSpan = "2">Action</th>
            </tr>
            {this.state.product.map((p,i)=>(
                <tr key = {i}>
                <td>{p._id}</td>
                <td>{p.p_name}</td>
                <td>{p.p_cost}</td>
                <td>{p.p_description}</td>
                <td><Link to={{pathname:'/update', state:{ product : p}}} class = "btn btn-primary">Update</Link></td>
                <td><button onClick = {()=>this.deleteP(p.p_name)}>Delete</button></td>
                </tr>
            ))}
            </table>
                <Link to = "/add_product" class = "btn btn-success">Add</Link>
            </div>

            
        )
    }
}
export default Show;