import React,{Component} from 'react'

const empData = {
    name:'Rajesh',
    pass:'123'
}

const EmpHOC = (EmployeeComponent)=>{
    class Employee extends Component{
        state = {
            data:empData
        }
        render()
        {
            return (
                <EmployeeComponent {...this.state}/>
            )
        }
    }
    return Employee;
}

class MyComponent extends Component
{
    render()
    {
        return (
            <div>
            {this.props.data.name}<br></br>
            {this.props.data.pass}
            </div>
        )
    }
}
export default EmpHOC(MyComponent)
