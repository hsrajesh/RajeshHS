var express = require("express")
var mongo = require("mongodb")
var cors = require("cors")
var url = "mongodb://localhost:27017/fullstack"
var bp = require("body-parser")

var app = express();

app.listen(4000,()=>{console.log("Server Connected")})
app.use(cors())
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.get("/all",(req,res)=>{

    mongo.connect(url,(err,dbp)=>{

        dbp.db("fullstack").collection("product").find().toArray((err,result)=>{
            return res.send(result)
        })
    })
})

app.post("/add",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        var b = {_id:req.body.id,p_name:req.body.pname,p_cost:req.body.pcost,p_description:req.body.pdes}
        db.db("fullstack").collection("product").insertOne(b,(err,result)=>{
            return res.send("added")
        })
    })
})

app.put("/save/:name",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("product").update({_id:req.params.name},{$set:{p_name:req.body.name,p_cost:req.body.cost,p_description:req.body.description}},(err,result)=>{
            return res.send("updated")
        })
    })
})

app.delete("/delete/:id",(req,res)=>{
    mongo.connect(url,(err,db)=>{
        db.db("fullstack").collection("product").deleteOne({p_name:req.params.id},(err,result)=>{
            return res.send("deleted")
        })
    })
})