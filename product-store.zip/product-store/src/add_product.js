import React,{Component} from 'react'
import Axios from 'axios';

class Add extends Component
{
    addP=()=>{
        let i = this.refs.id.value;
        let n = this.refs.name.value;
        let c = this.refs.cost.value;
        let d = this.refs.des.value;
        var body = {id:i,pname:n,pcost:c,pdes:d}
        Axios.post("http://localhost:4000/add",body)
        .then(()=>{
           this.props.history.push("/")

        })
    }

    render()
    {
        return (
            <div>
            <table>
            <tr>
            <th><label>ID:</label></th>
            <td><input type = "number" ref = "id" name = "pname"/></td>
            </tr>
            <tr>
            <th><label>Name:</label></th>
            <td><input type = "text" ref = "name" name = "pname"/></td>
            </tr>
            <tr>
            <th><label>Cost:</label></th>
            <td><input type = "number" ref = "cost" name = "pcost"/></td>
            </tr>
            <tr>
            <th><label>Description:</label></th>
            <td><input type = "text" ref = "des" name = "pdes"/></td>
            </tr>
            <tr><button onClick = {this.addP}>Add Product</button></tr>
            </table>
            </div>
        )
    }
}
export default Add;