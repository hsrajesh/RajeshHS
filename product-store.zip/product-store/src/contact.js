import React,{Component} from 'react'
import PropTypes from 'prop-types'

class Contact extends Component
{
    render()
    {
        return (
            <div>
            {this.props.name}<br></br>
            {this.props.mobile}
            </div>
        )
    }
}

Contact.PropTypes = {
    name:PropTypes.string.isRequired,
    mobile:PropTypes.string
}
Contact.defaultProps ={
    name:"Raj"
}
export default Contact;