import Recat,{Component} from 'react'
import Axios from 'axios';

class Delete extends Component
{
    constructor()
    {
        
    }
    render()
    {
        return (
            <div>
            </div>
        )
    }
}
export default Delete;