import React, {Component} from 'react'
import Axios from 'axios';

class Update extends Component{

    updateProduct = () =>{
        let i  = this.props.location.state.product._id
        let n = this.refs.name.value;
        let c = this.refs.cost.value;
        let d = this.refs.des.value;
        let pr = {id:i,name:n,cost:c,description:d}
        Axios.put("http://localhost:4000/save/" + i,pr )
        .then(()=>{
            this.props.history.push("/")
        })
        
    }
    render()
    {
        return (
            <div>
            <table>
            <tr>
            <th><label>ID:</label></th>
            <td><input type = "number" ref = "id" readonly defaultValue={this.props.location.state.product._id}/></td>
            </tr>
            <tr>
            <th><label>Name:</label></th>
            <td><input type = "text" ref = "name" defaultValue={this.props.location.state.product.p_name}/></td>
            </tr>
            <tr>
            <th><label>Cost:</label></th>
            <td><input type = "number" ref = "cost" defaultValue={this.props.location.state.product.p_cost}/></td>
            </tr>
            <tr>
            <th><label>Description:</label></th>
            <td><input type = "text" ref = "des" defaultValue={this.props.location.state.product.p_description}/></td>
            </tr>
            <tr><button onClick = {this.updateProduct}>Update</button></tr>
            </table>
            </div>
        )
    }
}
export default Update;