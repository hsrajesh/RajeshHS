import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter} from 'react-router-dom';
import {Link , Route} from 'react-router-dom'
import Show from './showAll'
import Update from './update'
import Add from './add_product'
import Home from './lab7.4/home';
import EmpHOC from './employee'
import Contact from './contact';


function App() {
  return (
    <div className="App">
    <BrowserRouter>
    {/*<Route exact path = "/" component = {Show}/>
    <Route path = "/update" component = {Update}/>
  <Route path = "/add_product" component = {Add}/>
    <Route exact path = "/" component = {Home}/>*/}
    </BrowserRouter>
    <EmpHOC />
    <Contact name = "Rajesh" mobile = "9591423721"/>
    </div>
  );
}

export default App;
