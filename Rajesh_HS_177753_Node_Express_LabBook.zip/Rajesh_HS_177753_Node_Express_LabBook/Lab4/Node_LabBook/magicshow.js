var mdb = require("mongodb");
var express = require("express");
var bp = require("body-parser");
var app = express();
var url = "mongodb://localhost:27017/fullstack"
var path = require("path");

app.set("view engine","pug")
app.listen(2000,()=>{console.log("server connected at http://localhost:2000")})
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.use(express.static(path.join(__dirname , "public")))

app.get('/',(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("magicworld").find().toArray((err,result)=>{

            res.render("index",{shows:result})
        })
    })
})

app.get("/book/:name",(req,res)=>{

    mdb.connect(url,(err,db)=>{
        db.db("fullstack").collection("magicworld").findOne({showName:req.params.name},(err,result)=>{

            res.render("BookNow",{showdetails:result})
        })
    })
})

app.post("/booknow",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("magicworld").updateOne({showName:req.body.name},{$set:{Availableseat:parseInt(req.body.seats) - parseInt(req.body.book)}},(err,result)=>{

            res.render("success",{Details:req.body})
        })
    })
})

