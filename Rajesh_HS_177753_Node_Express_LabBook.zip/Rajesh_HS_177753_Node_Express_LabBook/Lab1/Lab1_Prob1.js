
var file = require("fs")
  let employees = [

    {_id:1,name:"rajesh"},
    {_id:2,name:"sailaja"},
    {_id:3,name:"sudheer"},
    {_id:4,name:"karthika"},
    {_id:5,name:"suman"},
    {_id:6,name:"nitesh"}
  ]

  for(let i=0;i<employees.length;i++)
  {
       console.log(employees[i].name)
  }

//   file.appendFile("prob1.txt",employees,(err,res)=>{


//   })
  

  

