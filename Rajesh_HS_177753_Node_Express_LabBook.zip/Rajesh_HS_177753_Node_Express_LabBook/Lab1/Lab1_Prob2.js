
var file = require("fs")

var data = " Hello!, Good Evng"

file.appendFile("prob1.text",data,(err,res)=>{

    console.log(data);
})

file.readFile("Lab1_Prob1.js",(err,res)=>{

    console.log(res.toString())
})