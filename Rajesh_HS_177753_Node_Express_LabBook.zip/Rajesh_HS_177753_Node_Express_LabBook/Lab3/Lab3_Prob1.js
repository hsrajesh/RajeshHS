
var mdb = require("mongodb");
var url = "mongodb://localhost:27017/fullstack"
var express = require("express")
var bp = require("body-parser")



var app = express();
app.use(bp.urlencoded({extended:true}))
app.use(bp.json())


app.listen(2000,()=>{console.log("server connected at.... http://localhost:2000")})

//fetching the data from an array
app.get("/employee",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("employee").find().toArray((err,result)=>{

            if(err) throw err;
            res.send(result);
            res.end();
        })
    })
})

//inserting the data to the server
app.post("/employee",(req,res)=>{

    mdb.connect(url,(err,database)=>{

        var d = {empId:req.body.empId,empName:req.body.empName,empSalary:parseInt(req.body.empSalary), empAddress:{city:req.body.empAddress.city,state:req.body.empAddress.state}}
        database.db("fullstack").collection("employee").insertOne(d,(err,result)=>{

            res.send(result);
            res.end();
        })
    })
})

//displaying all employees

app.get("/employee/:state",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("employee").find({"empAddress.state":req.params.state}).toArray((err,result)=>{

            res.send(result);
            res.end();
        })
    })    
})

//Updating city of an employee

app.put("/employee/:city",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        db.db("fullstack").collection("employee").update({empId:1001},{$set:{"empAddress.city":req.params.city}},(err,result)=>{

            res.send(result);
            res.end();
        })
        })    
})

//Adding a new Employee

app.post("/employee",(req,res)=>{

    mdb.connect(url,(err,db)=>{

        var c = {empId:req.body.empId,empName:req.body.empName,empSalary:parseInt(req.body.empSalary), empAddress:{city:req.body.empAddress.city,state:req.body.empAddress.state}}
        db.db("fullstack").collection("employee").post(c,(err,result)=>{

            res.send(result);
            res.end();
        })
    })
})
