var mdb = require("mongodb")
var url = "mongodb://localhost:27017/fullstack";

mdb.connect(url,(err,db)=>{

    if(err) throw err;
    console.log("connected....")

//fetching the data from an array
db.db("fullstack").collection("employee").find().toArray((err,result)=>{

    if(err) throw err;

    console.log(result)
})

//Displaying the employees based on city
db.db("fullstack").collection("employee").find({"empAddress.state":"Karnataka"}).toArray((err,res)=>{

    if(err) throw err;
    console.log(res);
})

//Updating the city in an array
db.db("fullstack").collection("employee").update({empId:1007},{$set:{"empAddress.city":"Mandya"}},(err,result)=>{

    if(err) throw err;
    console.log(result)

    })

    //Inserting One more employee to an array
var p = {empId:"1008",empName:"Sudheer",empSalary:250000,empAddress:{city:"Ongole",state:"Telangana"}}
db.db("fullstack").collection("employee").insert(p,(err,result)=>{

    if(err) throw err;
    console.log(result);

})
})

