import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  mname;
  mrating;
  mgenre;


  constructor(private cd:MovieService) { }

    myForm = new FormGroup({

      mname:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z0-9]{1,}')]),
      mrating:new FormControl('',[Validators.required,Validators.pattern('[1-5].[0-9]{1}')]),
      mgenre:new FormControl('',[Validators.required])
    })


    error_messages =
      {
        "mname":
        [
          {type:'required',message:'Movie Name is required'},
          {type:'pattern',message:'Movie Name Should be only alphanumeric'}
        ],
        "mrating":
        [
          {type:'required',message:'Movie rating is required'},
          {type:'pattern',message:'Rating needs to be a number: eg:2.5. Rating is on scale 1-5'}
        ],
        "mgenre":
        [
          {type:'required',message:'Movie Genre is required'}
        ]
      }


      appMovie()
      {
        this.cd.addMovielist(this.mname,this.mrating,this.mgenre)
        .subscribe(()=>{
          alert("added");
        })
      }

  ngOnInit() {
  }

}
