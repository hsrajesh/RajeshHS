import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { SearchComponent } from './search/search.component';
import { MovielistComponent } from './movielist/movielist.component';

const routes: Routes =
[
  {path:'add',component:AddMovieComponent},
  {path:'search',component:SearchComponent},
  {path:'viewall',component:MovielistComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
