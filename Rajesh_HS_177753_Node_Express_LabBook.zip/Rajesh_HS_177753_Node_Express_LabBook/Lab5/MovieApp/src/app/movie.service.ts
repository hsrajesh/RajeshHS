import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  mgenre;
  constructor(private http:HttpClient) { }

  getDetails()
  {
    return this.http.get("http://localhost:5000/getall")
  }

  addMovielist(name,rateing,genre){

    var body = {name:name,rate:rateing,genre:genre}
    var head = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.post("http://localhost:5000/add",body,({headers:head}))
  }
  getGenre(genre)
  {
      return this.http.get("http://localhost:5000/find/"  + genre)
  }
}
