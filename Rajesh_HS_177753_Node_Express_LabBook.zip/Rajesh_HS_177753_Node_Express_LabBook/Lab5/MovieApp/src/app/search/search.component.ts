import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  msearch;
  movies;
  constructor(private cd: MovieService) {

  }

  searchMovie()
  {
      this.movies = this.cd.getGenre(this.msearch)
    .subscribe((data)=>{

      this.movies = data;
    })
  }

  ngOnInit() {
  }

}
