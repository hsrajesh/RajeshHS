import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movielist',
  templateUrl: './movielist.component.html',
  styleUrls: ['./movielist.component.css']
})
export class MovielistComponent implements OnInit {

  products;

  constructor(private cd:MovieService) {

    this.products = this.cd.getDetails().subscribe(data => this.products = data)


   }

  ngOnInit() {
  }

}
