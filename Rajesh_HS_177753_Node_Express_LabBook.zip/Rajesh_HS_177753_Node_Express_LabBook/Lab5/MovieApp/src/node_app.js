var mdb = require("mongodb");
var express = require("express");
var bp = require("body-parser");
var cors = require("cors");
var url = "mongodb://localhost:27017/fullstack"
var app = express();

app.use(bp.urlencoded({extended:true}))
app.use(bp.json())
app.use(cors())

app.listen(5000,()=>console.log("server started....."))

app.get("/getall",(req,res)=>{

  mdb.connect(url,(err,db)=>{

    db.db("fullstack").collection("movielist").find().toArray((err,result)=>{

      return res.json(result);
    })
  })
})

app.post('/add',(req,res)=>{

  var d = {name:req.body.name,rate:req.body.rate,genre:req.body.genre}
  mdb.connect(url,(err,db)=>{

    db.db("fullstack").collection("movielist").insertOne(d,(err,result)=>{
      return res.json(result);
    })
  })
})

app.get('/find/:genre',(req,res)=>{

  mdb.connect(url,(err,db)=>{

    db.db("fullstack").collection("movielist").find({genre:req.params.genre}).toArray((err,result)=>{

      return res.json(result);
    })
  })
})
