import React, { Component } from 'react';
import './App.css';
import AxiosExample from './AxiosExample';
class App extends Component {
  render() {
    
    return (
      <div>
        <AxiosExample/>
      </div>
    );
  }
}

export default App;
