import React, { Component } from 'react';
import styles from './App.module.css';


class App extends Component {
  render() {
    return (
      <div>
        <div className={styles['one']}>
          <h2>welcome</h2>
        </div>
      
      <h1>hello</h1>
      </div>
    );
  }
}

export default App;
