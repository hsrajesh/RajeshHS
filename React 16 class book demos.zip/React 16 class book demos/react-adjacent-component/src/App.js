import React, { Component } from 'react';

const Employee=()=>[
  <li key="1">ajay</li>,
  <li key="2">rahul</li>,
  <li key="3">ishaque</li>
]
 
class Emp extends Component{
  render(){
    return [
      <li key="1">avinash</li>,
      <li key="2">abhisek</li>
    ]
}
}
let shoppingCart = [
  {id: 35, item: 'jumper', color: 'red', size: 'medium', price: 20},
  {id: 35, item: 'shirt', color: 'blue', size: 'medium', price: 15},
  {id: 71, item: 'socks', color: 'black', size: 'all', price: 5},
  ]
class App extends Component{
    render(){
      const items = shoppingCart.map((item, key) =>
        <li key={item.id}>{item.name}</li>
        );
      return (
        <div>
          <h1>hi</h1>
        </div>
      <div>
        <li key="1">arun</li>
        <li key="2">ragul</li>
        {items}
        <Employee/>
        <Emp/>
        
      </div>
      );
    }
}
export default App;
