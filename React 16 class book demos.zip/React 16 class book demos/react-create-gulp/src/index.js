//import React from 'react';

//import ReactDOM from 'react-dom';

var App = require('./app');
var React = require('react');
var ReactDOM = require('react-dom');
//var gulp = require('gulp');
//var React = require('gulp-react');

ReactDOM.render(
    <App/>,document.getElementById('root')
)