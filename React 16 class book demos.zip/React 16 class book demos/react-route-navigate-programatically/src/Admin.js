import React from "react";
const Admin = () => {
    return (
      <div className="jumbotron">
        <h3 className="display-3">Admin Access granted</h3>
      </div>
    );
  }

  export default Admin;